package kr.hs.dgsw.dokdo;

import android.view.View;

public interface ItemClickListener {

    public void onItemClick(View v, int position);
}
